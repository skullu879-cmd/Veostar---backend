import os, uuid, base64, tempfile, mimetypes
from typing import Optional
import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field

FAL_KEY = os.getenv('FAL_KEY', '').strip()
T2V_MODEL = os.getenv('FAL_T2V_MODEL', 'fal-ai/wan/v2.2-5b/text-to-video')
I2V_MODEL = os.getenv('FAL_I2V_MODEL', 'fal-ai/wan/v2.2-5b/image-to-video')
app = FastAPI(title='VeoStar AI Backend', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=False, allow_methods=['*'], allow_headers=['*'])
jobs = {}

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=5000)
    style: str = 'cinematic'
    aspect_ratio: str = '16:9'
    duration_seconds: int = 5
    target_resolution: str = '720p'
    image_base64: Optional[str] = None

def auth_headers():
    if not FAL_KEY:
        raise HTTPException(503, 'Server setup incomplete: add FAL_KEY in Render Environment.')
    return {'Authorization': f'Key {FAL_KEY}', 'Content-Type': 'application/json'}

def style_prompt(prompt, style):
    styles = {'cinematic':'cinematic lighting, professional camera movement, detailed composition', 'realistic':'photorealistic detail, natural motion, realistic lighting', '3d_animation':'high-quality 3D animation, expressive movement, detailed materials', 'horror':'dark horror atmosphere, suspenseful cinematic lighting, eerie fog'}
    return prompt + '. ' + styles.get(style, styles['cinematic'])

def upload_image(data):
    try:
        from fal_client import upload
        raw = data.split(',', 1)[-1]
        binary = base64.b64decode(raw)
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as f:
            f.write(binary); path = f.name
        try:
            return upload(path)
        finally:
            os.unlink(path)
    except Exception as e:
        raise HTTPException(400, f'Image upload failed: {str(e)[:250]}')

def submit(model, payload):
    try:
        r = requests.post(f'https://queue.fal.run/{model}', headers=auth_headers(), json=payload, timeout=60)
        if r.status_code >= 400:
            raise HTTPException(r.status_code, f'fal.ai error: {r.text[:500]}')
        data = r.json(); jid = data.get('request_id')
        if not jid: raise HTTPException(502, 'fal.ai did not return a request id')
        jobs[jid] = {'model':model, 'status_url':data.get('status_url', f'https://queue.fal.run/{model}/requests/{jid}/status'), 'response_url':data.get('response_url', f'https://queue.fal.run/{model}/requests/{jid}'), 'status':'IN_QUEUE'}
        return jid
    except requests.RequestException as e:
        raise HTTPException(502, f'Could not reach fal.ai: {e}')

@app.get('/')
def root(): return {'service':'VeoStar AI Backend','status':'online','docs':'/docs'}
@app.get('/health')
def health(): return {'ok':True,'fal_configured':bool(FAL_KEY)}
@app.post('/api/enhance-prompt')
def enhance_prompt(prompt: str, target_style: str='cinematic'):
    return {'enhanced_prompt':style_prompt(prompt, target_style)}

@app.post('/api/generate/text-to-video')
def text_to_video(req: GenerateRequest):
    payload = {'prompt':style_prompt(req.prompt, req.style), 'aspect_ratio':req.aspect_ratio if req.aspect_ratio in ['16:9','9:16','1:1'] else '16:9', 'resolution':req.target_resolution if req.target_resolution in ['720p','1080p'] else '720p', 'duration':str(max(2,min(5,req.duration_seconds)))}
    jid = submit(T2V_MODEL, payload)
    return {'job_id':jid,'message':'Video request submitted to fal.ai'}

@app.post('/api/generate/image-to-video')
def image_to_video(req: GenerateRequest):
    if not req.image_base64: raise HTTPException(400, 'Please upload an image.')
    image_url = upload_image(req.image_base64)
    payload = {'prompt':style_prompt(req.prompt, req.style), 'image_url':image_url}
    jid = submit(I2V_MODEL, payload)
    return {'job_id':jid,'message':'Image-to-video request submitted to fal.ai'}

@app.get('/api/jobs/{job_id}/progress')
def progress(job_id: str):
    job=jobs.get(job_id)
    if not job: raise HTTPException(404, 'Job not found. Free server may have restarted; submit again.')
    try:
        r=requests.get(job['status_url'], headers={'Authorization':f'Key {FAL_KEY}'}, params={'logs':'false'}, timeout=30)
        if r.status_code>=400: raise HTTPException(r.status_code, r.text[:300])
        d=r.json(); status=d.get('status','IN_PROGRESS'); job['status']=status
        if status=='COMPLETED':
            rr=requests.get(job['response_url'], headers={'Authorization':f'Key {FAL_KEY}'}, timeout=60)
            rr.raise_for_status(); result=rr.json(); video=(result.get('video') or {}).get('url')
            if not video:
                # Some model outputs use a different file key.
                video=((result.get('output') or {}).get('video') or {}).get('url')
            if not video: raise HTTPException(502, 'fal.ai completed but returned no video URL.')
            job['video_url']=video
        if status=='FAILED': job['error']=d.get('error','Generation failed')
        return {'status':status.lower(),'progress':1 if status=='COMPLETED' else (0.5 if status=='IN_PROGRESS' else 0.1),'message':job.get('error') or status}
    except requests.RequestException as e: raise HTTPException(502, str(e))

@app.get('/api/jobs/{job_id}/video')
def video(job_id: str):
    job=jobs.get(job_id)
    if not job or not job.get('video_url'): raise HTTPException(404,'Video is not ready yet.')
    return RedirectResponse(job['video_url'])
