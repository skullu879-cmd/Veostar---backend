VeoStar Backend - Render + fal.ai

IMPORTANT: Never put your fal.ai key in source files or share it in chat.

Deploy on Render:
1. Put these files in a GitHub repository (repository root).
2. Render Dashboard > New > Web Service > connect that repository.
3. Runtime Python; Build Command: pip install -r requirements.txt
   Start Command: uvicorn main:app --host 0.0.0.0 --port $PORT
4. Select Free if desired.
5. After service is created, open Environment and add:
   Key: FAL_KEY
   Value: your fal.ai API key (paste privately in Render only)
6. Save and redeploy. Test https://YOUR-SERVICE.onrender.com/health

Then configure the Netlify front end's API_BASE to this service URL.

Video generation uses paid fal.ai model inference. Render Free services sleep when idle.
This starter backend keeps job state in memory; a free service restart can lose the local job record.
